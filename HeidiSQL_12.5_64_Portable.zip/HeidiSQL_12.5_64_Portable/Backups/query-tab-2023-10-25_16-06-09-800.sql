/*Geef de verschillende functies 
van de werknemers */
SELECT DISTINCT functie
FROM werknemer