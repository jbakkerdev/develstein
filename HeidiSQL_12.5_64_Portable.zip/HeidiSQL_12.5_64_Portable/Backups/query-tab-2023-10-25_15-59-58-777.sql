/*Geef naam, afdeling van alle 
werknemers van wie het jaarsalaris (salaris * 12) 
groter is dan 60.000.
Sorteer dit op afdeling. */
SELECT naam, afdeling, (salaris*12) AS jaarsalaris
FROM werknemer
WHERE (salaris*12) > 60000