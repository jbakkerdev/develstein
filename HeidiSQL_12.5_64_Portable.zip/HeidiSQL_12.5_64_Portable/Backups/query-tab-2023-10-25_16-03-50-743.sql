/* Geef  all gegevens van alle werknemers.
Sorteer dit op afdeling en naam */
SELECT *
FROM werknemer
ORDER BY afdeling, naam