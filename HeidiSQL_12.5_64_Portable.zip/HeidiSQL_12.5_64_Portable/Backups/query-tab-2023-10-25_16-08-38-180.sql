SELECT rnaam, COUNT(rnaam)
FROM dier
GROUP BY rnaam
ORDER BY COUNT(rnaam) DESC